��affine.R��and "randomization.R"  are two global scripts  all the simulations are nedded.
 
Please change the file path of each "source" function ,espacially note that functions of  accelerated EGO algorithm contain a "source" function

��UDxxx.txt��is the .txt file of the initial Uniform Design 



In  section_3 :

��AEGO_eg�� is the script of accelerated EGO algorithm
"demonstrative_eg" is the script of the demeonstrative exanple to show the prosses of iteration and the influence of QMC pool size


In section_4 and section_5 :

each folder contains the "algorithms_code" to store the functions of EGO, Constant Liar and Accelerated EGO algorithms
Just run the scripts of each test function, please check the file path is right


